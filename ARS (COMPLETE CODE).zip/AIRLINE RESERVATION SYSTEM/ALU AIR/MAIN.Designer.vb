﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MAIN
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CUSTOMER = New System.Windows.Forms.Button()
        Me.EMPLOYEE = New System.Windows.Forms.Button()
        Me.RESERVATION = New System.Windows.Forms.Button()
        Me.TICKET = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.FLIGHT = New System.Windows.Forms.Button()
        Me.AIRCRAFT = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SEAT = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CANCELFLI = New System.Windows.Forms.Button()
        Me.REBOOKFLI = New System.Windows.Forms.Button()
        Me.LOGOUT = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'CUSTOMER
        '
        Me.CUSTOMER.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSTOMER.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.CUSTOMER.Location = New System.Drawing.Point(98, 455)
        Me.CUSTOMER.Name = "CUSTOMER"
        Me.CUSTOMER.Size = New System.Drawing.Size(305, 122)
        Me.CUSTOMER.TabIndex = 2
        Me.CUSTOMER.Text = "CUSTOMER"
        Me.CUSTOMER.UseVisualStyleBackColor = True
        '
        'EMPLOYEE
        '
        Me.EMPLOYEE.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EMPLOYEE.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.EMPLOYEE.Location = New System.Drawing.Point(98, 583)
        Me.EMPLOYEE.Name = "EMPLOYEE"
        Me.EMPLOYEE.Size = New System.Drawing.Size(305, 93)
        Me.EMPLOYEE.TabIndex = 3
        Me.EMPLOYEE.Text = "EMPLOYEE"
        Me.EMPLOYEE.UseVisualStyleBackColor = True
        '
        'RESERVATION
        '
        Me.RESERVATION.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RESERVATION.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.RESERVATION.Location = New System.Drawing.Point(1071, 455)
        Me.RESERVATION.Name = "RESERVATION"
        Me.RESERVATION.Size = New System.Drawing.Size(305, 114)
        Me.RESERVATION.TabIndex = 6
        Me.RESERVATION.Text = "RESERVATION"
        Me.RESERVATION.UseVisualStyleBackColor = True
        '
        'TICKET
        '
        Me.TICKET.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TICKET.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.TICKET.Location = New System.Drawing.Point(1071, 575)
        Me.TICKET.Name = "TICKET"
        Me.TICKET.Size = New System.Drawing.Size(305, 101)
        Me.TICKET.TabIndex = 8
        Me.TICKET.Text = "TICKET"
        Me.TICKET.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Label1.Location = New System.Drawing.Point(521, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(452, 91)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "WELCOME"
        '
        'FLIGHT
        '
        Me.FLIGHT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FLIGHT.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.FLIGHT.Location = New System.Drawing.Point(98, 100)
        Me.FLIGHT.Name = "FLIGHT"
        Me.FLIGHT.Size = New System.Drawing.Size(305, 122)
        Me.FLIGHT.TabIndex = 10
        Me.FLIGHT.Text = "FLIGHT"
        Me.FLIGHT.UseVisualStyleBackColor = True
        '
        'AIRCRAFT
        '
        Me.AIRCRAFT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AIRCRAFT.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.AIRCRAFT.Location = New System.Drawing.Point(98, 228)
        Me.AIRCRAFT.Name = "AIRCRAFT"
        Me.AIRCRAFT.Size = New System.Drawing.Size(305, 122)
        Me.AIRCRAFT.TabIndex = 11
        Me.AIRCRAFT.Text = "AIRCRAFT"
        Me.AIRCRAFT.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Button1.Location = New System.Drawing.Point(1071, 100)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(305, 122)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "BOOK FLIGHT"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'SEAT
        '
        Me.SEAT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SEAT.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.SEAT.Location = New System.Drawing.Point(98, 356)
        Me.SEAT.Name = "SEAT"
        Me.SEAT.Size = New System.Drawing.Size(305, 93)
        Me.SEAT.TabIndex = 13
        Me.SEAT.Text = "SEAT"
        Me.SEAT.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.Alu_Air_8
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel1.Location = New System.Drawing.Point(409, 145)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(656, 424)
        Me.Panel1.TabIndex = 1
        '
        'CANCELFLI
        '
        Me.CANCELFLI.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CANCELFLI.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.CANCELFLI.Location = New System.Drawing.Point(1071, 356)
        Me.CANCELFLI.Name = "CANCELFLI"
        Me.CANCELFLI.Size = New System.Drawing.Size(305, 93)
        Me.CANCELFLI.TabIndex = 14
        Me.CANCELFLI.Text = "CANCEL FLIGHT"
        Me.CANCELFLI.UseVisualStyleBackColor = True
        '
        'REBOOKFLI
        '
        Me.REBOOKFLI.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.REBOOKFLI.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.REBOOKFLI.Location = New System.Drawing.Point(1071, 228)
        Me.REBOOKFLI.Name = "REBOOKFLI"
        Me.REBOOKFLI.Size = New System.Drawing.Size(305, 122)
        Me.REBOOKFLI.TabIndex = 15
        Me.REBOOKFLI.Text = "REBOOK FLIGHT"
        Me.REBOOKFLI.UseVisualStyleBackColor = True
        '
        'LOGOUT
        '
        Me.LOGOUT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LOGOUT.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.LOGOUT.Location = New System.Drawing.Point(691, 638)
        Me.LOGOUT.Name = "LOGOUT"
        Me.LOGOUT.Size = New System.Drawing.Size(148, 38)
        Me.LOGOUT.TabIndex = 16
        Me.LOGOUT.Text = "Logout"
        Me.LOGOUT.UseVisualStyleBackColor = True
        '
        'MAIN
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1469, 768)
        Me.Controls.Add(Me.LOGOUT)
        Me.Controls.Add(Me.REBOOKFLI)
        Me.Controls.Add(Me.CANCELFLI)
        Me.Controls.Add(Me.SEAT)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.AIRCRAFT)
        Me.Controls.Add(Me.FLIGHT)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TICKET)
        Me.Controls.Add(Me.RESERVATION)
        Me.Controls.Add(Me.EMPLOYEE)
        Me.Controls.Add(Me.CUSTOMER)
        Me.Controls.Add(Me.Panel1)
        Me.ForeColor = System.Drawing.Color.Blue
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "MAIN"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MAIN"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As Panel
    Friend WithEvents CUSTOMER As Button
    Friend WithEvents EMPLOYEE As Button
    Friend WithEvents RESERVATION As Button
    Friend WithEvents TICKET As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents FLIGHT As Button
    Friend WithEvents AIRCRAFT As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents SEAT As Button
    Friend WithEvents CANCELFLI As Button
    Friend WithEvents REBOOKFLI As Button
    Friend WithEvents LOGOUT As Button
End Class
