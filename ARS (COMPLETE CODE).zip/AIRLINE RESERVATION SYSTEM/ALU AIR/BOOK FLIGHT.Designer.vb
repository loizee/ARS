﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Book_Flight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PNRNOGEN = New System.Windows.Forms.Button()
        Me.PASSPORTNO = New System.Windows.Forms.TextBox()
        Me.CUSDOB = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CUSTEL = New System.Windows.Forms.TextBox()
        Me.CUSADDRESS = New System.Windows.Forms.TextBox()
        Me.PNRNO = New System.Windows.Forms.TextBox()
        Me.CUSEMAIL = New System.Windows.Forms.TextBox()
        Me.CUSMNAME = New System.Windows.Forms.TextBox()
        Me.CUSLNAME = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.CUSFNAME = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SEATID = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.FLIGHTID = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.BOOK = New System.Windows.Forms.Button()
        Me.BACK = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(5, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(180, 38)
        Me.Label1.TabIndex = 71
        Me.Label1.Text = "Book Flight"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.PNRNOGEN)
        Me.GroupBox1.Controls.Add(Me.PASSPORTNO)
        Me.GroupBox1.Controls.Add(Me.CUSDOB)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.CUSTEL)
        Me.GroupBox1.Controls.Add(Me.CUSADDRESS)
        Me.GroupBox1.Controls.Add(Me.PNRNO)
        Me.GroupBox1.Controls.Add(Me.CUSEMAIL)
        Me.GroupBox1.Controls.Add(Me.CUSMNAME)
        Me.GroupBox1.Controls.Add(Me.CUSLNAME)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.CUSFNAME)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 115)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1454, 291)
        Me.GroupBox1.TabIndex = 73
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Personal Information"
        '
        'PNRNOGEN
        '
        Me.PNRNOGEN.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PNRNOGEN.Location = New System.Drawing.Point(26, 35)
        Me.PNRNOGEN.Name = "PNRNOGEN"
        Me.PNRNOGEN.Size = New System.Drawing.Size(144, 42)
        Me.PNRNOGEN.TabIndex = 79
        Me.PNRNOGEN.Text = "PNR Number: "
        Me.PNRNOGEN.UseVisualStyleBackColor = True
        '
        'PASSPORTNO
        '
        Me.PASSPORTNO.Location = New System.Drawing.Point(935, 212)
        Me.PASSPORTNO.Margin = New System.Windows.Forms.Padding(4)
        Me.PASSPORTNO.Name = "PASSPORTNO"
        Me.PASSPORTNO.Size = New System.Drawing.Size(485, 22)
        Me.PASSPORTNO.TabIndex = 58
        '
        'CUSDOB
        '
        Me.CUSDOB.Location = New System.Drawing.Point(203, 212)
        Me.CUSDOB.Margin = New System.Windows.Forms.Padding(4)
        Me.CUSDOB.Name = "CUSDOB"
        Me.CUSDOB.Size = New System.Drawing.Size(485, 22)
        Me.CUSDOB.TabIndex = 57
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(743, 212)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(184, 32)
        Me.Label2.TabIndex = 56
        Me.Label2.Text = "Passport Number:"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(22, 212)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(135, 32)
        Me.Label3.TabIndex = 55
        Me.Label3.Text = "Date of Birth:"
        '
        'CUSTEL
        '
        Me.CUSTEL.Location = New System.Drawing.Point(935, 106)
        Me.CUSTEL.Margin = New System.Windows.Forms.Padding(4)
        Me.CUSTEL.Name = "CUSTEL"
        Me.CUSTEL.Size = New System.Drawing.Size(485, 22)
        Me.CUSTEL.TabIndex = 54
        '
        'CUSADDRESS
        '
        Me.CUSADDRESS.Location = New System.Drawing.Point(935, 76)
        Me.CUSADDRESS.Margin = New System.Windows.Forms.Padding(4)
        Me.CUSADDRESS.Name = "CUSADDRESS"
        Me.CUSADDRESS.Size = New System.Drawing.Size(485, 22)
        Me.CUSADDRESS.TabIndex = 53
        '
        'PNRNO
        '
        Me.PNRNO.Enabled = False
        Me.PNRNO.Location = New System.Drawing.Point(204, 46)
        Me.PNRNO.Margin = New System.Windows.Forms.Padding(4)
        Me.PNRNO.Name = "PNRNO"
        Me.PNRNO.Size = New System.Drawing.Size(484, 22)
        Me.PNRNO.TabIndex = 52
        Me.PNRNO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CUSEMAIL
        '
        Me.CUSEMAIL.Location = New System.Drawing.Point(935, 46)
        Me.CUSEMAIL.Margin = New System.Windows.Forms.Padding(4)
        Me.CUSEMAIL.Name = "CUSEMAIL"
        Me.CUSEMAIL.Size = New System.Drawing.Size(485, 22)
        Me.CUSEMAIL.TabIndex = 51
        '
        'CUSMNAME
        '
        Me.CUSMNAME.Location = New System.Drawing.Point(203, 152)
        Me.CUSMNAME.Margin = New System.Windows.Forms.Padding(4)
        Me.CUSMNAME.Name = "CUSMNAME"
        Me.CUSMNAME.Size = New System.Drawing.Size(485, 22)
        Me.CUSMNAME.TabIndex = 50
        '
        'CUSLNAME
        '
        Me.CUSLNAME.Location = New System.Drawing.Point(203, 182)
        Me.CUSLNAME.Margin = New System.Windows.Forms.Padding(4)
        Me.CUSLNAME.Name = "CUSLNAME"
        Me.CUSLNAME.Size = New System.Drawing.Size(485, 22)
        Me.CUSLNAME.TabIndex = 49
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(743, 106)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(184, 32)
        Me.Label4.TabIndex = 48
        Me.Label4.Text = "Telephone Number:"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(743, 76)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(96, 32)
        Me.Label5.TabIndex = 47
        Me.Label5.Text = "Address:"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(743, 47)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(96, 32)
        Me.Label6.TabIndex = 46
        Me.Label6.Text = "Email:"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(22, 182)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(136, 32)
        Me.Label7.TabIndex = 45
        Me.Label7.Text = "Last Name:"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(22, 152)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(148, 32)
        Me.Label8.TabIndex = 44
        Me.Label8.Text = "Middle Name:"
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(22, 122)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(148, 32)
        Me.Label9.TabIndex = 43
        Me.Label9.Text = "First Name:"
        '
        'CUSFNAME
        '
        Me.CUSFNAME.Location = New System.Drawing.Point(203, 122)
        Me.CUSFNAME.Margin = New System.Windows.Forms.Padding(4)
        Me.CUSFNAME.Name = "CUSFNAME"
        Me.CUSFNAME.Size = New System.Drawing.Size(485, 22)
        Me.CUSFNAME.TabIndex = 41
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.TextBox12)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.TextBox10)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.TextBox11)
        Me.GroupBox2.Location = New System.Drawing.Point(759, 412)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(707, 279)
        Me.GroupBox2.TabIndex = 74
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Payment"
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(-5, 183)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(167, 32)
        Me.Label15.TabIndex = 45
        Me.Label15.Text = "CVC:"
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(188, 183)
        Me.TextBox12.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(485, 22)
        Me.TextBox12.TabIndex = 44
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(-5, 122)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(185, 32)
        Me.Label13.TabIndex = 43
        Me.Label13.Text = "Card Expiration:"
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(188, 122)
        Me.TextBox10.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(485, 22)
        Me.TextBox10.TabIndex = 42
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(-4, 58)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(167, 32)
        Me.Label14.TabIndex = 41
        Me.Label14.Text = "Card Number:"
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(188, 58)
        Me.TextBox11.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(485, 22)
        Me.TextBox11.TabIndex = 40
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Button2)
        Me.GroupBox3.Controls.Add(Me.Button1)
        Me.GroupBox3.Controls.Add(Me.SEATID)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.FLIGHTID)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 412)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(736, 279)
        Me.GroupBox3.TabIndex = 75
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Flight "
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(204, 212)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(118, 42)
        Me.Button2.TabIndex = 46
        Me.Button2.Text = "View Seats"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(203, 87)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(119, 42)
        Me.Button1.TabIndex = 45
        Me.Button1.Text = "View Flights"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'SEATID
        '
        Me.SEATID.Location = New System.Drawing.Point(204, 183)
        Me.SEATID.Margin = New System.Windows.Forms.Padding(4)
        Me.SEATID.Name = "SEATID"
        Me.SEATID.Size = New System.Drawing.Size(485, 22)
        Me.SEATID.TabIndex = 44
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(22, 183)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(148, 32)
        Me.Label11.TabIndex = 43
        Me.Label11.Text = "Seat ID:"
        '
        'FLIGHTID
        '
        Me.FLIGHTID.Location = New System.Drawing.Point(203, 58)
        Me.FLIGHTID.Margin = New System.Windows.Forms.Padding(4)
        Me.FLIGHTID.Name = "FLIGHTID"
        Me.FLIGHTID.Size = New System.Drawing.Size(485, 22)
        Me.FLIGHTID.TabIndex = 42
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(22, 58)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(148, 32)
        Me.Label12.TabIndex = 41
        Me.Label12.Text = "Flight ID:"
        '
        'BOOK
        '
        Me.BOOK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BOOK.Location = New System.Drawing.Point(1310, 732)
        Me.BOOK.Name = "BOOK"
        Me.BOOK.Size = New System.Drawing.Size(122, 42)
        Me.BOOK.TabIndex = 76
        Me.BOOK.Text = "Book"
        Me.BOOK.UseVisualStyleBackColor = True
        '
        'BACK
        '
        Me.BACK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BACK.Location = New System.Drawing.Point(1182, 732)
        Me.BACK.Name = "BACK"
        Me.BACK.Size = New System.Drawing.Size(122, 42)
        Me.BACK.TabIndex = 78
        Me.BACK.Text = "Back"
        Me.BACK.UseVisualStyleBackColor = True
        '
        'Book_Flight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1478, 818)
        Me.Controls.Add(Me.BACK)
        Me.Controls.Add(Me.BOOK)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Book_Flight"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Book_Flight"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Private WithEvents PASSPORTNO As TextBox
    Private WithEvents CUSDOB As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Private WithEvents CUSTEL As TextBox
    Private WithEvents CUSADDRESS As TextBox
    Private WithEvents PNRNO As TextBox
    Private WithEvents CUSEMAIL As TextBox
    Private WithEvents CUSMNAME As TextBox
    Private WithEvents CUSLNAME As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Private WithEvents CUSFNAME As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Private WithEvents SEATID As TextBox
    Friend WithEvents Label11 As Label
    Private WithEvents FLIGHTID As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Private WithEvents TextBox10 As TextBox
    Friend WithEvents Label14 As Label
    Private WithEvents TextBox11 As TextBox
    Friend WithEvents Label15 As Label
    Private WithEvents TextBox12 As TextBox
    Friend WithEvents BOOK As Button
    Friend WithEvents BACK As Button
    Friend WithEvents PNRNOGEN As Button
End Class
